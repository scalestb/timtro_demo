<template>
  <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
    <div class="container">
      <!-- Brand -->
      <router-link class="navbar-brand d-flex align-items-center" to="/">
        <img src="@/assets/logo.png" alt="Logo" height="32">
      </router-link>

      <!-- Language Switcher -->
      <div class="ms-auto">
        <div class="dropdown">
          <button 
            class="btn btn-link dropdown-toggle text-dark text-decoration-none"
            type="button" 
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            <i class="fas fa-globe me-2"></i>
            {{ currentLanguage }}
          </button>
          <ul class="dropdown-menu dropdown-menu-end">
            <li>
              <button 
                class="dropdown-item" 
                @click="changeLanguage('vi')"
                :class="{ active: currentLanguage === 'Tiếng Việt' }"
              >
                Tiếng Việt
              </button>
            </li>
            <li>
              <button 
                class="dropdown-item" 
                @click="changeLanguage('en')"
                :class="{ active: currentLanguage === 'English' }"
              >
                English
              </button>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </nav>
</template>

<script>
import { computed, onMounted } from 'vue';
import { useTranslation } from '../locales';

export default {
  name: 'NavBar',
  setup() {
    const { locale, setLanguage } = useTranslation();

    const currentLanguage = computed(() => {
      return locale.value === 'vi' ? 'Tiếng Việt' : 'English';
    });

    const changeLanguage = (lang) => {
      setLanguage(lang);
    };

    onMounted(() => {
      // Initialize Bootstrap dropdown
      if (typeof bootstrap !== 'undefined') {
        const dropdownElementList = document.querySelectorAll('.dropdown-toggle');
        dropdownElementList.forEach(dropdownToggle => {
          new bootstrap.Dropdown(dropdownToggle);
        });
      }
    });

    return {
      currentLanguage,
      changeLanguage
    };
  }
};
</script>

<style scoped>
.navbar {
  box-shadow: 0 2px 4px rgba(0,0,0,.08);
  height: 56px;
}

.navbar-brand img {
  height: 32px;
  width: auto;
}

.dropdown-toggle::after {
  vertical-align: middle;
}

.dropdown-item {
  cursor: pointer;
}

.dropdown-item.active {
  background-color: var(--bs-primary);
  color: white;
}

.dropdown-item:active {
  background-color: var(--bs-primary);
}

@media (min-width: 768px) {
  .navbar {
    height: 72px;
  }

  .navbar-brand img {
    height: 40px;
  }
}
</style>

