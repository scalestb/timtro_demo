<template>
  <div class="others-page">
    <h1 class="page-title">Có Nhà Đất .VN</h1>
    <p class="page-subtitle">
      Cập nhật thông tin mới nhất từ <br> Có Nhà Đất VN
    </p>

    <section class="feature-section">
      <h2 class="section-title">Tính năng sắp phát triển</h2>
      <ul class="feature-list">
        <li>🔍 Tìm phòng trọ qua bản đồ</li>
        <li>📝 Đăng ký thành viên, đăng tin cho thuê</li>
        <li>📋 Quản lý tin đăng chuyên nghiệp</li>
      </ul>
    </section>

    <section class="recruit-section">
      <h2 class="section-title">Tuyển cộng tác viên</h2>
      <p>
        Có Nhà Đất cần tuyển cộng tác viên hỗ trợ khách xem phòng và xem nhà.
      </p>
      <p>Tham gia nhóm Zalo</p>
      <div>
        <a href="https://zalo.me/g/nmupvr476" target="_blank">Link đăng ký</a>
      </div>
    </section>

    <section class="info-section">
      <h2 class="section-title">Thông tin website</h2>
      <div class="info-box">
        <p>Website: Có Nhà Đất</p>
        <p>Founder: BinhVPT</p>
        <p>Phiên bản: 1.0.0</p>
        <p>Ngày cập nhật: 13-04-2025</p>
      </div>
    </section>

    <div class="quick-nav-fixed">
      <QuickNavigation />
    </div>
  </div>
</template>

<script>
import QuickNavigation from "@/components/QuickNavigation.vue";

export default {
  name: "OthersPage",
  components: {
    QuickNavigation,
  },
};
</script>

<style src="@/assets/css/pages/others.css"></style>
